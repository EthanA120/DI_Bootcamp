create function rpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function rpad() is 'right-pad string to length';

alter function rpad() owner to postgres;

